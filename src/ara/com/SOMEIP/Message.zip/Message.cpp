/**
 * @file Message.cpp
 * @author Flashing Adapter Graduation Project Team
 * @version 0.1
 * @date 2022-03-07
 *
 * @copyright Copyright (c) 2022
 *
 */
#include "ara/com/SOMEIP/Message.h"
#include <cstdint>
#include <cstring>
#include <unistd.h>

namespace ara::com::SOMEIP_MESSAGE {

Message::Message(header_t new_header,
                 std::vector<uint8_t> const &new_payload) noexcept
    : header(new_header), payload(new_payload) {}

Message::Message(struct Message_ID mID, struct Request_ID rID,
                 uint8_t protocol_version, uint8_t interface_version,
                 enum MessageType Mtype, enum ReturnCode Rcode) noexcept {
  header.service_id = mID.serivce_id;
  header.method_id = mID.method_id;
  header.client_id = rID.client_id;
  header.session_id = rID.session_id;
  header.protocol_version = protocol_version;
  header.interface_version = interface_version;
  header.message_type = static_cast<int>(Mtype);
  header.return_code = static_cast<int>(Rcode);
  header.length = sizeof(header_t);
}
Message::Message(struct Message_ID mID, struct Request_ID rID,
                 uint8_t protocol_version, uint8_t interface_version,
                 enum MessageType Mtype) noexcept
    : Message(mID, rID, protocol_version, interface_version, Mtype,
              ReturnCode::E_OK) {}

Message::Message(Request_ID rID, Message_ID mID, uint8_t protocol_version,
                 uint8_t interface_version, ReturnCode Rcode,
                 MessageType Mtype) noexcept
    : Message(mID, rID, protocol_version, interface_version, Mtype, Rcode) {}

struct Message_ID Message::MessageId() const noexcept {
  return {(uint16_t)header.method_id, (uint16_t)header.service_id};
}

uint16_t Message::ClientId() const noexcept { return header.client_id; }

uint16_t Message::SessionId() const noexcept { return header.session_id; }

void Message::SetSessionId(uint16_t sessionId) {
  header.session_id = sessionId;
}

bool Message::IncrementSessionId() noexcept {
  const uint8_t SessionIdMin = 1;
  constexpr uint8_t SessionIdMax = std::numeric_limits<uint8_t>::max();

  if (header.session_id == SessionIdMax) {
    header.session_id = SessionIdMin;
    return true;
  } else {
    header.session_id++;
    return false;
  }
}

uint8_t Message::ProtocolVersion() const noexcept {
  return header.protocol_version;
}

uint8_t Message::InterfaceVersion() const noexcept {
  return header.interface_version;
}

MessageType Message::Messagetype() const noexcept {
  return static_cast<MessageType>(header.message_type);
}

ReturnCode Message::Returncode() const noexcept {
  return static_cast<ReturnCode>(header.return_code);
}
uint32_t Message::Length() noexcept { return header.length; }

std::vector<uint8_t> Message::Serializer() {
  std::vector<uint8_t> result;
  Message_ID mid = MessageId();

  helper::Inject(result, mid.serivce_id);
  helper::Inject(result, mid.method_id);
  helper::Inject(result, header.length);
  helper::Inject(result, ClientId());
  helper::Inject(result, SessionId());
  result.push_back(ProtocolVersion());
  result.push_back(InterfaceVersion());

  auto messageType = static_cast<uint8_t>(MessageType());
  result.push_back(messageType);

  auto returnCode = static_cast<uint8_t>(ReturnCode());
  result.push_back(returnCode);
  // concatenate result and payload and put them in the result
  result.insert(result.end(), payload.begin(), payload.end());

  return result;
}
void Message::SetPayload(std::vector<uint8_t> const &data) {
  payload = data;
  header.length += payload.size();
}

Message Message::Deserialize(const std::vector<uint8_t> &msg) {
  header_t header;
  std::vector<uint8_t> payload;

  memcpy(&header, msg.data(), sizeof(header_t));
  payload = std::vector<uint8_t>(msg.begin() + sizeof(header_t), msg.end());
  return Message(header, payload);

  /**
     uint32_t offset = 0;
    Message_ID _mid;
    _mid.serivce_id = msg[offset] << 8 | msg[offset + 1];
    _mid.method_id = msg[offset + 2] << 8 | msg[offset + 3];
    offset += 4;
    uint32_t length;
    length = msg[offset] << 24 | msg[offset + 1] << 16 | msg[offset + 2] << 8 |
             msg[offset + 3];
    offset += 4;
    Request_ID _rid;
    _rid.client_id = msg[offset] << 8 | msg[offset + 1];
    _rid.session_id = msg[offset + 2] << 8 | msg[offset + 3];
    offset += 4;

    uint8_t GBProtocol_Version = msg[offset];
    uint8_t GBinterface_version = msg[offset + 1];
    MessageType GBMessageType = static_cast<MessageType>(msg[offset + 2]);
    ReturnCode GBReturnCode = static_cast<ReturnCode>(msg[offset + 3]);
    offset += 4;

    Message m(_mid, _rid, GBProtocol_Version, GBinterface_version,
    GBMessageType, GBReturnCode);

    if (length > HeaderSize) {
      std::vector<uint8_t> pay = {msg.begin() + offset, msg.begin() + length};
      m.SetPayload(pay);
    }
    return m;
    */
}

Message &Message::operator=(Message &msg) {
  header.method_id = msg.MessageId().method_id;
  header.length = msg.Length();
  header.client_id = msg.ClientId();
  header.session_id = msg.SessionId();
  header.protocol_version = msg.ProtocolVersion();
  header.interface_version = msg.InterfaceVersion();
  header.message_type = static_cast<uint8_t>(msg.Messagetype());
  header.return_code = static_cast<uint8_t>(msg.Returncode());
  payload = msg.Serializer();
  return *this;
}

std::vector<uint8_t> Message::getload() const { return payload; }
std::vector<uint8_t> Message::GetPayload() const { return payload; }

} // namespace ara::com::SOMEIP_MESSAGE
